# Jam Bicara (Android)

Aplikasi jam bicara untuk tunanetra. Mengucapkan jam, hari, tanggal Masehi, tanggal Hijriyah,
dan sisa baterai dengan suara bahasa Indonesia, setiap interval yang bisa diatur (1 sampai 1440 menit).
Tetap berbunyi saat layar mati, dan menyala sendiri setelah HP dihidupkan ulang.

Contoh ucapan (Selasa, 27 Oktober 2026, pukul 08.00, 20 Safar 1448, baterai 75 persen):

> Sekarang pukul delapan pagi. Hari Selasa, tanggal dua puluh tujuh Oktober dua ribu dua puluh enam.
> Bertepatan dengan tanggal dua puluh Safar seribu empat ratus empat puluh delapan Hijriyah.
> Sisa baterai tujuh puluh lima persen.

## Cara membuat APK

### Cara A: tanpa memasang apa pun di komputer (GitHub)

1. Buat akun di github.com, lalu buat repositori baru.
2. Unggah seluruh isi folder ini (termasuk folder `.github`) ke repositori itu.
3. Buka tab **Actions**, pilih **Build APK**, tekan **Run workflow**.
4. Tunggu sekitar 3 sampai 6 menit. Buka hasil proses yang selesai, lalu unduh **JamBicara-apk**.
5. Ekstrak berkas zip itu. Di dalamnya ada `app-debug.apk`.

### Cara B: Android Studio

1. Pasang Android Studio, lalu pilih **Open** dan buka folder ini.
2. Tunggu sinkronisasi Gradle selesai.
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Memasang di HP

1. Salin `app-debug.apk` ke HP, lalu buka berkasnya.
2. Izinkan pemasangan dari sumber ini bila diminta.
3. Buka aplikasi, izinkan notifikasi, lalu tekan **Mulai jam bicara**.

## Pengaturan penting

- Volume dan nada: pilih **Jalur suara** (Alarm, Media, atau Notifikasi) dan atur **Volume jam bicara** di aplikasi. Dengan jalur Alarm, volumenya terpisah dari volume media. Volume HP dikembalikan setelah setiap pengumuman. Nada awal (naik) dan nada akhir (turun) yang keras bisa dimatikan lewat kotak centang.
- Pasang suara bahasa Indonesia: tombol **Pengaturan suara** di aplikasi membuka pengaturan Teks-ke-Suara.
- Agar tidak dihentikan sistem: tombol **Buka pengaturan baterai**, lalu pilih aplikasi Jam Bicara dan izinkan tanpa pembatasan.
- Agar menyala sendiri setelah HP dihidupkan ulang: tombol **Izinkan menyala otomatis**. Pada HP Xiaomi atau Redmi, hidupkan Mulai otomatis (Autostart) untuk Jam Bicara. Jam bicara hanya menyala sendiri bila terakhir kali dalam keadaan aktif, dan baru berjalan setelah HP dibuka kuncinya.
- Tanggal Hijriyah dihitung otomatis (kalender Umm al-Qura). Gunakan **Koreksi tanggal Hijriyah** bila berbeda satu hari dengan keputusan pemerintah.
- Sebutan sisa baterai bisa dimatikan lewat kotak centang **Sebut sisa baterai di akhir**.

## Persyaratan

Android 8.0 (API 26) atau lebih baru.
