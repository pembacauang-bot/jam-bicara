package id.jambicara

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Menyalakan kembali jam bicara setelah HP dihidupkan ulang, bila sebelumnya aktif. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        if (a == Intent.ACTION_BOOT_COMPLETED || a == "android.intent.action.QUICKBOOT_POWERON") {
            if (Prefs(context).active) {
                try {
                    ClockService.boot(context)
                } catch (e: Exception) {
                    // Sistem menolak memulai layanan; pengguna bisa menekan Mulai secara manual.
                }
            }
        }
    }
}
