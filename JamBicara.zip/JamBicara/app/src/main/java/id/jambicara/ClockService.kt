package id.jambicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.util.Date
import java.util.Locale

/**
 * Layanan latar depan yang mengucapkan jam sesuai interval.
 * Tetap berjalan saat layar mati karena memegang wake lock sebagian.
 */
class ClockService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "id.jambicara.START"
        const val ACTION_STOP = "id.jambicara.STOP"
        const val ACTION_SPEAK = "id.jambicara.SPEAK"
        const val ACTION_RESCHEDULE = "id.jambicara.RESCHEDULE"
        const val ACTION_BOOT = "id.jambicara.BOOT"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL = "jambicara"
        private const val NOTIF_ID = 1

        /** Waktu pengumuman berikutnya, dibaca oleh layar utama. */
        @Volatile
        var nextAt: Long = 0L

        private fun send(c: Context, action: String, text: String? = null) {
            val i = Intent(c, ClockService::class.java).setAction(action)
            if (text != null) i.putExtra(EXTRA_TEXT, text)
            c.startForegroundService(i)
        }

        fun start(c: Context) = send(c, ACTION_START)
        fun stop(c: Context) = send(c, ACTION_STOP)
        fun reschedule(c: Context) = send(c, ACTION_RESCHEDULE)
        fun boot(c: Context) = send(c, ACTION_BOOT)

        /** Ucapkan [text]; bila null, ucapkan jam dan tanggal saat ini. */
        fun speak(c: Context, text: String?) = send(c, ACTION_SPEAK, text)
    }

    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private val tick = Runnable { onTick() }

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel(CHANNEL, "Jam Bicara", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts?.setLanguage(Locale("id", "ID"))
        tts?.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (!Prefs(this@ClockService).active) stopSelf()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (!Prefs(this@ClockService).active) stopSelf()
            }
        })
        ready = true
        pending?.let { speakText(it) }
        pending = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        enterForeground()
        val prefs = Prefs(this)
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.active = false
                handler.removeCallbacks(tick)
                nextAt = 0L
                releaseLock()
                speakText("Jam bicara berhenti.")
                handler.postDelayed({ stopSelf() }, 8000)
            }
            ACTION_SPEAK -> {
                speakText(intent.getStringExtra(EXTRA_TEXT) ?: nowSentence())
                if (!prefs.active) handler.postDelayed({ if (!Prefs(this).active) stopSelf() }, 30000)
            }
            ACTION_START -> {
                prefs.active = true
                acquireLock()
                scheduleNext()
                speakText("Jam bicara aktif. Interval " + Speech.intervalKata(prefs.interval) + ".")
            }
            ACTION_BOOT -> {
                if (prefs.active) {
                    acquireLock()
                    scheduleNext()
                    speakText("Jam bicara aktif kembali. Interval " + Speech.intervalKata(prefs.interval) + ".")
                } else {
                    stopSelf()
                }
            }
            ACTION_RESCHEDULE -> {
                if (prefs.active) {
                    acquireLock()
                    scheduleNext()
                } else {
                    stopSelf()
                }
            }
            else -> {
                // Layanan dihidupkan ulang oleh sistem.
                if (prefs.active) {
                    acquireLock()
                    scheduleNext()
                } else {
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    private fun nowSentence(): String {
        val p = Prefs(this)
        val t = LocalDateTime.now()
        val hj = if (p.sayHijri) Speech.hijri(t.toLocalDate(), p.offset) else null
        return Speech.kalimat(t, hj, p.sayDate, p.sayHijri, p.sayBattery, batteryPercent())
    }

    private fun batteryPercent(): Int? {
        return try {
            val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val v = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (v in 0..100) v else null
        } catch (e: Exception) {
            null
        }
    }

    private fun speakText(text: String) {
        val engine = tts
        if (!ready || engine == null) {
            pending = text
            return
        }
        engine.setSpeechRate(Prefs(this).rate)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    private fun scheduleNext() {
        val p = Prefs(this)
        nextAt = Speech.computeNext(System.currentTimeMillis(), p.interval, p.align)
        postTick()
        updateNotification()
    }

    private fun postTick() {
        handler.removeCallbacks(tick)
        val d = maxOf(nextAt - System.currentTimeMillis(), 0L)
        handler.postDelayed(tick, minOf(d, 30_000L))
    }

    private fun onTick() {
        val p = Prefs(this)
        if (!p.active) return
        val now = System.currentTimeMillis()
        if (now >= nextAt - 200) {
            speakText(nowSentence())
            nextAt = Speech.computeNext(maxOf(now, nextAt), p.interval, p.align)
            updateNotification()
        }
        postTick()
    }

    private fun acquireLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jambicara:clock").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (e: Exception) {
        }
        wakeLock = null
    }

    private fun buildNotification(): Notification {
        val p = Prefs(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ClockService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (p.active && nextAt > 0) {
            "Aktif setiap ${p.interval} menit. Berikutnya pukul " +
                SimpleDateFormat("HH.mm", Locale.US).format(Date(nextAt))
        } else {
            "Siap digunakan"
        }
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Jam Bicara")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    "Hentikan",
                    stop
                ).build()
            )
            .build()
    }

    private fun enterForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releaseLock()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
