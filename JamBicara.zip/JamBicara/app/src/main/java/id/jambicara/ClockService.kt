package id.jambicara

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Layanan latar depan yang mengucapkan jam sesuai interval.
 * Tetap berjalan saat layar mati karena memegang wake lock sebagian.
 *
 * Urutan setiap pengumuman: atur volume -> nada awal -> ucapan -> nada akhir -> volume dikembalikan.
 */
class ClockService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "id.jambicara.START"
        const val ACTION_STOP = "id.jambicara.STOP"
        const val ACTION_SPEAK = "id.jambicara.SPEAK"
        const val ACTION_RESCHEDULE = "id.jambicara.RESCHEDULE"
        const val ACTION_BOOT = "id.jambicara.BOOT"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL = "jambicara"
        private const val NOTIF_ID = 1

        /** Waktu pengumuman berikutnya, dibaca oleh layar utama. */
        @Volatile
        var nextAt: Long = 0L

        private fun send(c: Context, action: String, text: String? = null) {
            val i = Intent(c, ClockService::class.java).setAction(action)
            if (text != null) i.putExtra(EXTRA_TEXT, text)
            c.startForegroundService(i)
        }

        fun start(c: Context) = send(c, ACTION_START)
        fun stop(c: Context) = send(c, ACTION_STOP)
        fun reschedule(c: Context) = send(c, ACTION_RESCHEDULE)
        fun boot(c: Context) = send(c, ACTION_BOOT)

        /** Ucapkan [text]; bila null, ucapkan jam dan tanggal saat ini. */
        fun speak(c: Context, text: String?) = send(c, ACTION_SPEAK, text)
    }

    private class Pending(val text: String, val tones: Boolean)

    @Volatile
    private var tts: TextToSpeech? = null

    @Volatile
    private var ready = false
    private var pending: Pending? = null
    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private val tick = Runnable { onTick() }

    /** Semua pemutaran suara berjalan berurutan di satu utas latar. */
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val toneFlags = ConcurrentHashMap<String, Boolean>()

    @Volatile
    private var savedVol = -1

    @Volatile
    private var savedStream = AudioManager.STREAM_MUSIC

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel(CHANNEL, "Jam Bicara", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts?.setLanguage(Locale("id", "ID"))
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                finishUtterance(utteranceId)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finishUtterance(utteranceId)
            }
        })
        ready = true
        val p = pending
        pending = null
        if (p != null) say(p.text, p.tones)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        enterForeground()
        val prefs = Prefs(this)
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.active = false
                handler.removeCallbacks(tick)
                nextAt = 0L
                releaseLock()
                say("Jam bicara berhenti.", false)
                handler.postDelayed({ stopSelf() }, 8000)
            }
            ACTION_SPEAK -> {
                say(intent?.getStringExtra(EXTRA_TEXT) ?: nowSentence(), true)
                if (!prefs.active) handler.postDelayed({ if (!Prefs(this).active) stopSelf() }, 30000)
            }
            ACTION_START -> {
                prefs.active = true
                acquireLock()
                scheduleNext()
                say("Jam bicara aktif. Interval " + Speech.intervalKata(prefs.interval) + ".", false)
            }
            ACTION_BOOT -> {
                if (prefs.active) {
                    acquireLock()
                    scheduleNext()
                    say("Jam bicara aktif kembali. Interval " + Speech.intervalKata(prefs.interval) + ".", false)
                } else {
                    stopSelf()
                }
            }
            ACTION_RESCHEDULE -> {
                if (prefs.active) {
                    acquireLock()
                    scheduleNext()
                } else {
                    stopSelf()
                }
            }
            else -> {
                // Layanan dihidupkan ulang oleh sistem.
                if (prefs.active) {
                    acquireLock()
                    scheduleNext()
                } else {
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    private fun nowSentence(): String {
        val p = Prefs(this)
        val t = LocalDateTime.now()
        val hj = if (p.sayHijri) Speech.hijri(t.toLocalDate(), p.offset) else null
        return Speech.kalimat(t, hj, p.sayDate, p.sayHijri, p.sayBattery, batteryPercent())
    }

    private fun batteryPercent(): Int? {
        return try {
            val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val v = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (v in 0..100) v else null
        } catch (e: Exception) {
            null
        }
    }

    // ---- suara, nada, dan volume ----

    private fun streamType(p: Prefs): Int = when (p.stream) {
        0 -> AudioManager.STREAM_ALARM
        1 -> AudioManager.STREAM_MUSIC
        else -> AudioManager.STREAM_NOTIFICATION
    }

    private fun usage(p: Prefs): Int = when (p.stream) {
        0 -> AudioAttributes.USAGE_ALARM
        1 -> AudioAttributes.USAGE_MEDIA
        else -> AudioAttributes.USAGE_NOTIFICATION
    }

    /** Menjadwalkan nada awal, ucapan, dan nada akhir. [tones] false untuk pesan singkat seperti "Jam bicara aktif". */
    private fun say(text: String, tones: Boolean) {
        if (!ready || tts == null) {
            pending = Pending(text, tones)
            return
        }
        try {
            io.execute { sayNow(text, tones) }
        } catch (e: Exception) {
        }
    }

    private fun sayNow(text: String, tones: Boolean) {
        val engine = tts ?: return
        val p = Prefs(this)
        prepareVolume(p)
        val withTones = tones && p.tones
        if (withTones) Tones.playStart(usage(p))
        val id = "u" + System.nanoTime()
        toneFlags[id] = withTones
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(usage(p))
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        engine.setSpeechRate(p.rate)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun finishUtterance(id: String?) {
        val withTone = if (id != null) toneFlags.remove(id) == true else false
        try {
            io.execute {
                if (withTone) Tones.playEnd(usage(Prefs(this)))
                restoreVolume()
                if (!Prefs(this).active) stopSelf()
            }
        } catch (e: Exception) {
        }
    }

    private fun prepareVolume(p: Prefs) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val st = streamType(p)
            if (savedVol < 0) {
                savedStream = st
                savedVol = am.getStreamVolume(st)
            }
            val max = am.getStreamMaxVolume(st)
            val level = Math.round(max * p.volume / 100f).coerceIn(1, max)
            am.setStreamVolume(st, level, 0)
        } catch (e: Exception) {
            // Sistem menolak mengubah volume (misalnya mode Jangan Ganggu); pakai volume saat ini.
        }
    }

    private fun restoreVolume() {
        try {
            if (savedVol >= 0) {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(savedStream, savedVol, 0)
            }
        } catch (e: Exception) {
        }
        savedVol = -1
    }

    // ---- jadwal ----

    private fun scheduleNext() {
        val p = Prefs(this)
        nextAt = Speech.computeNext(System.currentTimeMillis(), p.interval, p.align)
        postTick()
        updateNotification()
    }

    private fun postTick() {
        handler.removeCallbacks(tick)
        val d = maxOf(nextAt - System.currentTimeMillis(), 0L)
        handler.postDelayed(tick, minOf(d, 30_000L))
    }

    private fun onTick() {
        val p = Prefs(this)
        if (!p.active) return
        val now = System.currentTimeMillis()
        if (now >= nextAt - 200) {
            say(nowSentence(), true)
            nextAt = Speech.computeNext(maxOf(now, nextAt), p.interval, p.align)
            updateNotification()
        }
        postTick()
    }

    private fun acquireLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jambicara:clock").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (e: Exception) {
        }
        wakeLock = null
    }

    private fun buildNotification(): Notification {
        val p = Prefs(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ClockService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (p.active && nextAt > 0) {
            "Aktif setiap ${p.interval} menit. Berikutnya pukul " +
                SimpleDateFormat("HH.mm", Locale.US).format(Date(nextAt))
        } else {
            "Siap digunakan"
        }
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Jam Bicara")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    "Hentikan",
                    stop
                ).build()
            )
            .build()
    }

    private fun enterForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        restoreVolume()
        releaseLock()
        io.shutdownNow()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
