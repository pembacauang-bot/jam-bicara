package id.jambicara

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Layar pengaturan. Semua kontrol besar dan berlabel agar nyaman dengan TalkBack. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var intervalEdit: EditText
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            updateStatus()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(top: Int = 12) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun label(s: String, size: Float = 18f, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun heading(s: String) = label(s, 22f, true).apply {
        if (Build.VERSION.SDK_INT >= 28) isAccessibilityHeading = true
    }

    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        textSize = 18f
        isAllCaps = false
        minHeight = dp(64)
        minimumHeight = dp(64)
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(40))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(label("Jam Bicara", 32f, true).apply {
            if (Build.VERSION.SDK_INT >= 28) isAccessibilityHeading = true
        })
        root.addView(label("Menyebutkan jam dan tanggal dengan suara, setiap interval yang Anda atur."), lp(4))

        status = label("", 18f, true).apply { accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }
        root.addView(status, lp(20))

        toggle = button("Mulai jam bicara") {
            if (prefs.active) {
                prefs.active = false
                ClockService.stop(this)
            } else {
                prefs.active = true
                ClockService.start(this)
            }
            updateStatus()
        }.apply { minHeight = dp(80); minimumHeight = dp(80); textSize = 22f }
        root.addView(toggle, lp(12))

        root.addView(button("Ucapkan sekarang") { ClockService.speak(this, null) }, lp(12))

        // ---- Interval ----
        root.addView(heading("Interval"), lp(32))
        val grid = GridLayout(this).apply { columnCount = 3 }
        for (n in intArrayOf(1, 5, 10, 15, 30, 60)) {
            val b = button("$n menit") { setInterval(n) }
            val p = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply { width = 0 }
            grid.addView(b, p)
        }
        root.addView(grid, lp(8))

        root.addView(label("Atau ketik sendiri, dalam menit (1 sampai 1440)"), lp(16))
        intervalEdit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 22f
            setText(prefs.interval.toString())
            contentDescription = "Interval dalam menit"
        }
        root.addView(intervalEdit, lp(4))
        root.addView(button("Terapkan interval") { applyInterval() }, lp(8))

        root.addView(CheckBox(this).apply {
            text = "Selaraskan dengan jam bulat (misalnya 08.00, 08.30, 09.00)"
            textSize = 18f
            minHeight = dp(56)
            isChecked = prefs.align
            setOnCheckedChangeListener { _, v ->
                prefs.align = v
                if (prefs.active) ClockService.reschedule(this@MainActivity)
            }
        }, lp(12))

        // ---- Isi ucapan ----
        root.addView(heading("Yang diucapkan"), lp(32))
        root.addView(CheckBox(this).apply {
            text = "Sebut hari dan tanggal"
            textSize = 18f
            minHeight = dp(56)
            isChecked = prefs.sayDate
            setOnCheckedChangeListener { _, v -> prefs.sayDate = v }
        }, lp(8))
        root.addView(CheckBox(this).apply {
            text = "Sebut tanggal Hijriyah"
            textSize = 18f
            minHeight = dp(56)
            isChecked = prefs.sayHijri
            setOnCheckedChangeListener { _, v -> prefs.sayHijri = v }
        }, lp(4))
        root.addView(CheckBox(this).apply {
            text = "Sebut sisa baterai di akhir"
            textSize = 18f
            minHeight = dp(56)
            isChecked = prefs.sayBattery
            setOnCheckedChangeListener { _, v -> prefs.sayBattery = v }
        }, lp(4))

        root.addView(label("Koreksi tanggal Hijriyah"), lp(12))
        val offsets = arrayOf(
            "Mundur dua hari", "Mundur satu hari", "Sesuai perhitungan (Umm al-Qura)",
            "Maju satu hari", "Maju dua hari"
        )
        root.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, offsets)
            setSelection(prefs.offset.coerceIn(-2, 2) + 2)
            contentDescription = "Koreksi tanggal Hijriyah"
            minimumHeight = dp(56)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    prefs.offset = pos - 2
                }

                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }, lp(4))
        root.addView(
            label("Awal bulan Hijriyah bisa berbeda satu hari dengan keputusan pemerintah. Pakai koreksi ini bila tanggal yang diucapkan belum cocok.", 15f),
            lp(4)
        )

        // ---- Suara ----
        root.addView(heading("Suara"), lp(32))
        val rateLabel = label("", 18f)
        fun showRate() {
            rateLabel.text = "Kecepatan bicara: " + String.format(Locale("id"), "%.1f", prefs.rate) + " kali"
        }
        showRate()
        root.addView(rateLabel, lp(8))
        root.addView(SeekBar(this).apply {
            max = 10
            progress = ((prefs.rate - 0.5f) * 10f).roundToInt().coerceIn(0, 10)
            contentDescription = "Kecepatan bicara"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    prefs.rate = 0.5f + p / 10f
                    showRate()
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }, lp(4))
        root.addView(label("Jalur suara"), lp(16))
        root.addView(Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Alarm (volume terpisah dari media)", "Media", "Notifikasi")
            )
            setSelection(prefs.stream.coerceIn(0, 2))
            contentDescription = "Jalur suara"
            minimumHeight = dp(56)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    prefs.stream = pos
                }

                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }, lp(4))

        val volLabel = label("", 18f)
        fun showVol() {
            volLabel.text = "Volume jam bicara: ${prefs.volume} persen"
        }
        showVol()
        root.addView(volLabel, lp(16))
        root.addView(SeekBar(this).apply {
            max = 9
            progress = (prefs.volume / 10 - 1).coerceIn(0, 9)
            contentDescription = "Volume jam bicara"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    prefs.volume = (p + 1) * 10
                    showVol()
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }, lp(4))

        root.addView(CheckBox(this).apply {
            text = "Bunyikan nada awal dan nada akhir"
            textSize = 18f
            minHeight = dp(56)
            isChecked = prefs.tones
            setOnCheckedChangeListener { _, v -> prefs.tones = v }
        }, lp(8))

        root.addView(button("Pengaturan suara (Teks-ke-Suara)") {
            try {
                startActivity(Intent("com.android.settings.TTS_SETTINGS"))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }, lp(12))
        root.addView(
            label("Bila suara belum berbahasa Indonesia, pasang bahasa Indonesia pada mesin Teks-ke-Suara di pengaturan ini.", 15f),
            lp(4)
        )

        // ---- Contoh ----
        root.addView(heading("Contoh ucapan lengkap"), lp(32))
        root.addView(
            label("Untuk hari Selasa, 27 Oktober 2026, pukul 08.00, dengan tanggal Hijriyah 20 Safar 1448, dan sisa baterai 75 persen.", 15f),
            lp(4)
        )
        val sample = Speech.kalimat(
            LocalDateTime.of(2026, 10, 27, 8, 0), Speech.Hijri(20, 2, 1448), true, true, true, 75
        )
        root.addView(label(sample, 20f), lp(8))
        root.addView(button("Dengarkan contoh") { ClockService.speak(this, sample) }, lp(12))

        root.addView(heading("Cara jam disebutkan"), lp(24))
        val lines = StringBuilder()
        for (hm in arrayOf(0 to 0, 4 to 45, 8 to 15, 12 to 0, 15 to 30, 21 to 5)) {
            val t = LocalDateTime.of(2026, 10, 27, hm.first, hm.second)
            lines.append(Speech.fmtHM(t)).append("  ").append(Speech.waktuKata(t)).append('\n')
        }
        root.addView(label(lines.toString().trimEnd()), lp(8))

        // ---- Latar belakang ----
        root.addView(heading("Agar tetap berbunyi"), lp(32))
        root.addView(
            label("Setelah menekan Mulai, jam bicara tetap berjalan saat layar mati. Bila berhenti sendiri, izinkan aplikasi ini berjalan tanpa pembatasan baterai.", 15f),
            lp(4)
        )
        root.addView(button("Buka pengaturan baterai") {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }, lp(12))

        root.addView(button("Izinkan menyala otomatis setelah HP dihidupkan") { openAutostart() }, lp(12))
        root.addView(
            label("Jam bicara yang aktif akan menyala sendiri setelah HP dihidupkan ulang. Pada HP Xiaomi atau Redmi, hidupkan Mulai otomatis (Autostart) untuk aplikasi ini. Pada HP lain, buka info aplikasi dan izinkan berjalan di latar belakang.", 15f),
            lp(4)
        )

        // Bila jam bicara sedang aktif (misalnya aplikasi dibuka ulang), pastikan layanan berjalan.
        if (prefs.active) ClockService.reschedule(this)
        updateStatus()
    }

    private fun openAutostart() {
        val candidates = listOf(
            Intent().setComponent(
                ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
            ),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
        for (i in candidates) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
            }
        }
    }

    private fun applyInterval() {
        val n = (intervalEdit.text.toString().toIntOrNull() ?: prefs.interval).coerceIn(1, 1440)
        setInterval(n)
    }

    private fun setInterval(n: Int) {
        prefs.interval = n
        intervalEdit.setText(n.toString())
        if (prefs.active) ClockService.reschedule(this)
        updateStatus()
    }

    private fun updateStatus() {
        val s = if (prefs.active) {
            val n = ClockService.nextAt
            if (n > 0) {
                "Aktif setiap ${prefs.interval} menit. Pengumuman berikutnya pukul " +
                    SimpleDateFormat("HH.mm", Locale.US).format(Date(n)) + "."
            } else {
                "Aktif setiap ${prefs.interval} menit."
            }
        } else {
            "Belum aktif. Tekan Mulai agar jam bicara berjalan sesuai interval."
        }
        if (status.text.toString() != s) status.text = s
        val b = if (prefs.active) "Hentikan jam bicara" else "Mulai jam bicara"
        if (toggle.text.toString() != b) toggle.text = b
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }
}
