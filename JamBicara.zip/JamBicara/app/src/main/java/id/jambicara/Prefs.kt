package id.jambicara

import android.content.Context

/** Pengaturan yang disimpan di perangkat. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("jambicara", Context.MODE_PRIVATE)

    /** Interval pengumuman dalam menit (1 sampai 1440). */
    var interval: Int
        get() = sp.getInt("interval", 30)
        set(v) { sp.edit().putInt("interval", v).apply() }

    /** Selaras dengan jam bulat: 08.00, 08.30, 09.00, dst. */
    var align: Boolean
        get() = sp.getBoolean("align", true)
        set(v) { sp.edit().putBoolean("align", v).apply() }

    var sayDate: Boolean
        get() = sp.getBoolean("sayDate", true)
        set(v) { sp.edit().putBoolean("sayDate", v).apply() }

    var sayHijri: Boolean
        get() = sp.getBoolean("sayHijri", true)
        set(v) { sp.edit().putBoolean("sayHijri", v).apply() }

    /** Sebut sisa baterai di akhir ucapan. */
    var sayBattery: Boolean
        get() = sp.getBoolean("sayBattery", true)
        set(v) { sp.edit().putBoolean("sayBattery", v).apply() }

    /** Koreksi tanggal Hijriyah dalam hari (-2 sampai 2). */
    var offset: Int
        get() = sp.getInt("offset", 0)
        set(v) { sp.edit().putInt("offset", v).apply() }

    var rate: Float
        get() = sp.getFloat("rate", 0.9f)
        set(v) { sp.edit().putFloat("rate", v).apply() }

    /** True selama pengguna menyalakan jam bicara. */
    var active: Boolean
        get() = sp.getBoolean("active", false)
        set(v) { sp.edit().putBoolean("active", v).apply() }
}
