package id.jambicara

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.chrono.HijrahChronology
import java.time.temporal.ChronoField
import java.util.Calendar

/** Menyusun kalimat yang diucapkan: jam, tanggal Masehi, tanggal Hijriyah. */
object Speech {
    private val HARI = arrayOf("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")
    private val BULAN = arrayOf(
        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
    )
    private val HBULAN = arrayOf(
        "Muharam", "Safar", "Rabiul Awal", "Rabiul Akhir", "Jumadil Awal", "Jumadil Akhir",
        "Rajab", "Syakban", "Ramadan", "Syawal", "Zulkaidah", "Zulhijah"
    )
    private val SAT = arrayOf(
        "nol", "satu", "dua", "tiga", "empat", "lima",
        "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas"
    )

    data class Hijri(val d: Int, val m: Int, val y: Int)

    /** Angka menjadi kata, misalnya 2026 menjadi "dua ribu dua puluh enam". */
    fun terbilang(n: Int): String = when {
        n < 12 -> SAT[n]
        n < 20 -> SAT[n - 10] + " belas"
        n < 100 -> SAT[n / 10] + " puluh" + (if (n % 10 > 0) " " + SAT[n % 10] else "")
        n < 200 -> "seratus" + (if (n > 100) " " + terbilang(n - 100) else "")
        n < 1000 -> SAT[n / 100] + " ratus" + (if (n % 100 > 0) " " + terbilang(n % 100) else "")
        n < 2000 -> "seribu" + (if (n > 1000) " " + terbilang(n - 1000) else "")
        else -> terbilang(n / 1000) + " ribu" + (if (n % 1000 > 0) " " + terbilang(n % 1000) else "")
    }

    private fun periode(h: Int): String = when {
        h == 0 -> "malam"
        h < 4 -> "dini hari"
        h < 11 -> "pagi"
        h < 15 -> "siang"
        h < 18 -> "sore"
        else -> "malam"
    }

    fun waktuKata(t: LocalDateTime): String {
        val h = t.hour
        val m = t.minute
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "pukul " + terbilang(h12) +
            (if (m > 0) " lewat " + terbilang(m) + " menit" else "") +
            " " + periode(h)
    }

    fun fmtHM(t: LocalDateTime): String = "%02d.%02d".format(t.hour, t.minute)

    /** Tanggal Hijriyah (Umm al-Qura) dengan koreksi hari. */
    fun hijri(date: LocalDate, offset: Int): Hijri? = try {
        val h = HijrahChronology.INSTANCE.date(date.plusDays(offset.toLong()))
        Hijri(h.get(ChronoField.DAY_OF_MONTH), h.get(ChronoField.MONTH_OF_YEAR), h.get(ChronoField.YEAR))
    } catch (e: Exception) {
        null
    }

    fun kalimat(
        t: LocalDateTime,
        hj: Hijri?,
        sayDate: Boolean,
        sayHijri: Boolean,
        sayBattery: Boolean = false,
        battery: Int? = null
    ): String {
        val out = ArrayList<String>()
        out.add("Sekarang " + waktuKata(t) + ".")
        if (sayDate) {
            out.add(
                "Hari " + HARI[t.dayOfWeek.value - 1] + ", tanggal " + terbilang(t.dayOfMonth) +
                    " " + BULAN[t.monthValue - 1] + " " + terbilang(t.year) + "."
            )
        }
        if (sayHijri && hj != null) {
            out.add(
                "Bertepatan dengan tanggal " + terbilang(hj.d) + " " + HBULAN[hj.m - 1] +
                    " " + terbilang(hj.y) + " Hijriyah."
            )
        }
        if (sayBattery && battery != null) {
            out.add("Sisa baterai " + terbilang(battery) + " persen.")
        }
        return out.joinToString(" ")
    }

    fun intervalKata(menit: Int): String =
        if (menit % 60 == 0) terbilang(menit / 60) + " jam" else terbilang(menit) + " menit"

    /** Waktu pengumuman berikutnya (milidetik epoch) setelah [from]. */
    fun computeNext(from: Long, intervalMenit: Int, align: Boolean): Long {
        val step = intervalMenit * 60_000L
        if (!align) return from + step
        val cal = Calendar.getInstance()
        cal.timeInMillis = from
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val mid = cal.timeInMillis
        var n = ((from - mid) / step + 1) * step
        if (n > 86_400_000L) n = 86_400_000L
        return mid + n
    }
}
