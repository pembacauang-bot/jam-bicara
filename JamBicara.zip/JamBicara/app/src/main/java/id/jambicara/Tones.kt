package id.jambicara

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Nada pembuka (naik) dan nada penutup (turun). Dibuat langsung dari gelombang suara,
 * tanpa berkas audio. Bentuk gelombangnya dibuat tajam dan penuh supaya terdengar keras.
 */
object Tones {
    private const val SR = 44100

    private val START = render(listOf(784.0 to 130, 1047.0 to 130, 1568.0 to 280))
    private val END = render(listOf(1568.0 to 130, 1047.0 to 130, 784.0 to 280))

    fun playStart(usage: Int) = play(START, usage)
    fun playEnd(usage: Int) = play(END, usage)

    private fun render(notes: List<Pair<Double, Int>>): ShortArray {
        val gap = SR * 25 / 1000
        val fade = SR * 12 / 1000
        var total = 0
        for (n in notes) total += SR * n.second / 1000 + gap
        val out = ShortArray(total)
        var pos = 0
        for (note in notes) {
            val f = note.first
            val n = SR * note.second / 1000
            for (i in 0 until n) {
                var env = 1.0
                if (i < fade) env = i / fade.toDouble()
                if (i >= n - fade) env = (n - i) / fade.toDouble()
                val x = tanh(2.2 * sin(2.0 * PI * f * i / SR)) / tanh(2.2)
                out[pos + i] = (x * env * 32000.0).toInt().toShort()
            }
            pos += n + gap
        }
        return out
    }

    /** Memutar nada dan menunggu sampai selesai. Panggil dari utas latar, bukan utas utama. */
    private fun play(data: ShortArray, usage: Int) {
        var track: AudioTrack? = null
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(usage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val fmt = AudioFormat.Builder()
                .setSampleRate(SR)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val t = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(data.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track = t
            t.write(data, 0, data.size)
            t.play()
            Thread.sleep(data.size * 1000L / SR + 120)
        } catch (e: Exception) {
            // Nada gagal diputar; ucapan tetap jalan.
        } finally {
            try {
                track?.stop()
            } catch (e: Exception) {
            }
            track?.release()
        }
    }
}
